# WaveScape Ignition Portal

This is the project folder for the WaveScape Ignition Portal GUI.

## Dependencies

- npm >= 8.1.2
- node >= v16.13.1

## Folders

- src
   - This folder includes Pivotal global styles and all the components & features
- public
   - This folder includes the index.html for rendering the app
